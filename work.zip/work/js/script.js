function showProfessionals(){
                        document.getElementsByClassName("professional-solution-description")[0].style.display="block";
                        document.getElementsByClassName("img-professionals")[0].style.display="block";
                        document.getElementsByClassName("professionals-ico")[0].classList.add("btn-fill");
                        
                        document.getElementsByClassName("beginners-ico")[0].classList.remove("btn-fill");
                        document.getElementsByClassName("agencies-ico")[0].classList.remove("btn-fill");
                        document.getElementsByClassName("beginner-solution-description")[0].style.display="none";
                        document.getElementsByClassName("agencies-solution-description")[0].style.display="none";
                        document.getElementsByClassName("img-agencies")[0].style.display="none";
                        document.getElementsByClassName("img-beginners")[0].style.display="none";
                        
      
}

function showBeginner(){
                        
                        document.getElementsByClassName("beginner-solution-description")[0].style.display="block";
                        document.getElementsByClassName("img-beginners")[0].style.display="block";
                        document.getElementsByClassName("beginners-ico")[0].classList.add("btn-fill");
                        
                        document.getElementsByClassName("professionals-ico")[0].classList.remove("btn-fill");
                        document.getElementsByClassName("agencies-ico")[0].classList.remove("btn-fill");
                      
                        document.getElementsByClassName("professional-solution-description")[0].style.display="none";
                        document.getElementsByClassName("agencies-solution-description")[0].style.display="none";
                        document.getElementsByClassName("img-professionals")[0].style.display="none";
                        document.getElementsByClassName("img-agencies")[0].style.display="none";
}

function showAgencies(){
                        document.getElementsByClassName("agencies-solution-description")[0].style.display="block";
                        document.getElementsByClassName("img-agencies")[0].style.display="block";
                        document.getElementsByClassName("agencies-ico")[0].classList.add("btn-fill");
                        
                        document.getElementsByClassName("professionals-ico")[0].classList.remove("btn-fill");
                        document.getElementsByClassName("beginners-ico")[0].classList.remove("btn-fill");
                        
                        document.getElementsByClassName("professional-solution-description")[0].style.display="none";
                        document.getElementsByClassName("beginner-solution-description")[0].style.display="none";
                        document.getElementsByClassName("img-professionals")[0].style.display="none";
                        document.getElementsByClassName("img-beginners")[0].style.display="none";
}

window.addEventListener("scroll",function(){
    if(pageYOffset>0){
        document.getElementsByClassName("menu-alternate")[0].style.top="0px"
    } else if(pageYOffset==0){
        document.getElementsByClassName("menu-alternate")[0].style.top="-94px"
    }
})

function startNameFocus(){
    document.getElementsByClassName("label-name")[0].classList.add("focus");
}
function saveNameFocus(){
    
    if (document.getElementById("name").value!=''){
        document.getElementsByClassName("label-name")[0].classList.add("focus");    
    } else {
        document.getElementsByClassName("label-name")[0].classList.remove("focus");
    
    }
}

function startEmailFocus(){
    document.getElementsByClassName("label-email")[0].classList.add("focus");
}
function saveEmailFocus(){
    
    
    if (document.getElementById("email").value!=''){
        document.getElementsByClassName("label-email")[0].classList.add("focus");    
    } else {
        document.getElementsByClassName("label-email")[0].classList.remove("focus");
    
    }
}

function startAreaFocus(){
    document.getElementsByClassName("label-textarea")[0].classList.add("focus");
}
function saveAreaFocus(){
    
    if (document.getElementById("email").value!=''){
        document.getElementsByClassName("label-textarea")[0].classList.add("focus");    
    } else {
        document.getElementsByClassName("label-textarea")[0].classList.remove("focus");
    
    
    }
}


function initCalc(){
    var slider = document.getElementById("events-scale");
    var output = document.getElementById("events-value");
    var planName   = document.getElementById("plan-name");
    var planPrice   = document.getElementById("plan-price");
    var planIncluded   = document.getElementById("plan-included");
    var overagePrice   = document.getElementById("overage-price");
    var overageValue   = document.getElementById("overage-value");
    var totalPrice   = document.getElementById("total-price");
    var totalValue   = document.getElementById("total-value");
      
    output.innerHTML = "100,000";
    planName.innerHTML      = "Basic";
    planPrice.innerHTML     = "$ "+0;
    planIncluded.innerHTML  = "100,000";
    overagePrice.innerHTML  = "$ "+0;
    overageValue.innerHTML  = 0;
    totalPrice.innerHTML    = "$ "+0;


    slider.oninput = function() {
        if (this.value<=25){
            var currentValue=100000+(this.value/25)*(1000000-100000);
            var newStr=String(currentValue).slice(0,3)+","+String(currentValue).slice(3,6);
            if (currentValue==1000000){
                newStr="1,000,000";
            }
            output.innerHTML        = newStr;
            planName.innerHTML      = "Basic";
            planPrice.innerHTML     = "$ "+0;
            planIncluded.innerHTML  = "100,000";
            overagePrice.innerHTML  = "$ "+Math.trunc((currentValue-100000)*0.00006);
            overageValue.innerHTML  = (currentValue-100000);
            totalPrice.innerHTML    = "$ "+Math.trunc((currentValue-100000)*0.00006);
            if (currentValue==1000000){
         
                planName.innerHTML      = "Professional";
                planPrice.innerHTML     = "$ "+49;
                planIncluded.innerHTML  = "1,000,000";
                overagePrice.innerHTML  = "$ "+0;
                overageValue.innerHTML  = 0;
                totalPrice.innerHTML    = "$ "+49;
            }
        }  
        if ((this.value>25)&&(this.value<=50)){
            currentValue=1000000+(this.value-25)*((10000000-1000000)/25);
            newStr=String(currentValue).slice(0,1)+","+String(currentValue).slice(1,4)+","+String(currentValue).slice(4,7);
            if (currentValue==10000000){
                newStr="10,000,000";
            }
            output.innerHTML = newStr;
            planName.innerHTML      = "Professional";
            planPrice.innerHTML     = "$ "+49;
            planIncluded.innerHTML  = "1,000,000";
            overagePrice.innerHTML  = "$ "+Math.trunc((currentValue-1000000)*0.000025);
            overageValue.innerHTML  = (currentValue-1000000);
            totalPrice.innerHTML    = "$ "+(Math.trunc((currentValue-1000000)*0.000025)+49);
            
            if (currentValue==10000000){
                planName.innerHTML      = "Business";
                planPrice.innerHTML     = "$ "+249;
                planIncluded.innerHTML  = "10,000,000";
                overagePrice.innerHTML  = "$ "+0;
                overageValue.innerHTML  = 0;
                totalPrice.innerHTML    = "$ "+249;
            }
    
    
        }
        if ((this.value>50)&&(this.value<=75)){
            currentValue=10000000+(this.value-50)*((30000000-10000000)/25);
            newStr=String(currentValue).slice(0,2)+","+String(currentValue).slice(2,5)+","+String(currentValue).slice(5,8);
            if (currentValue==30000000){
                newStr="30,000,000";
            }
            output.innerHTML = newStr;
            planName.innerHTML      = "Business";
            planPrice.innerHTML     = "$ "+249;
            planIncluded.innerHTML  = "10,000,000";
            overagePrice.innerHTML  = "$ "+Math.trunc((currentValue-10000000)*0.000013);
            overageValue.innerHTML  = (currentValue-10000000);
            totalPrice.innerHTML    = "$ "+(Math.trunc((currentValue-10000000)*0.000013)+249);
            
            if (currentValue==30000000){
                planName.innerHTML      = "Business";
                planPrice.innerHTML     = "$ "+499;
                planIncluded.innerHTML  = "30,000,000";
                overagePrice.innerHTML  = "$ "+0;
                overageValue.innerHTML  = 0;
                totalPrice.innerHTML    = "$ "+499;
            }
        }
        if ((this.value>75)&&(this.value<=100)){
            currentValue=30000000+(this.value-75)*((100000000-30000000)/25);
            newStr=String(currentValue).slice(0,2)+","+String(currentValue).slice(2,5)+","+String(currentValue).slice(5,8);
            if (currentValue==100000000){
                newStr="100,000,000";
            }
            output.innerHTML = newStr;
            planName.innerHTML      = "Enterprise";
            planPrice.innerHTML     = "$ "+499;
            planIncluded.innerHTML  = "30,000,000";
            overagePrice.innerHTML  = "$ "+Math.trunc((currentValue-30000000)*0.00001);
            overageValue.innerHTML  = (currentValue-30000000);
            totalPrice.innerHTML    = "$ "+(Math.trunc((currentValue-30000000)*0.00001)+499);
            
            if (currentValue==30000000){
                planName.innerHTML      = "Business";
                planPrice.innerHTML     = "$ "+499;
                planIncluded.innerHTML  = "30,000,000";
                overagePrice.innerHTML  = "$ "+0;
                overageValue.innerHTML  = 0;
                totalPrice.innerHTML    = "$ "+499;
            }
        }
      
    }
    
    
}

function startSubFocus(){
    document.getElementsByClassName("form-control")[0].classList.add("focus");
}
function saveSubFocus(){
    
    
    if (document.getElementById("email").value!=''){
        document.getElementsByClassName("label-email")[0].classList.add("focus");    
    } else {
        document.getElementsByClassName("label-email")[0].classList.remove("focus");
    
    }
}